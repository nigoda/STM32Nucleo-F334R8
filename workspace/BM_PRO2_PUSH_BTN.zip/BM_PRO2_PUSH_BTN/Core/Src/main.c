#include "stm32f3xx.h"
void delay(unsigned int a)
{
	int i,j;
	for(j=0;j<a;j++)
		for(i=0;i<6000;i++);
}

int main()
{
	RCC->AHBENR = (1U<<17) | (1U<<19);
	GPIOA->MODER |= (1U<<10);
	GPIOA->MODER &=~(1U<<11);

	GPIOA->MODER &=~(1U<<26) | (1U<<27);
	while(1)
	{
		if(GPIOC->IDR & (1<<13))
		{
			GPIOA->ODR |= (1U<<5);
//			delay(1000);
		}

		else
		{
			GPIOA->ODR &=~(1U<<5);
//			delay(1000);

		}

	}
}
