#include "stm32f3xx.h"
#include "stdio.h"
uint8_t uart_rx(void);
void uart_tx(char c);
void uart_str(unsigned char *ptr);
void delay(unsigned int a);

int main()
{
	RCC->AHBENR=(1U<<17);
	GPIOA->MODER|= (1U<<5)|(1U<<7);
	GPIOA->MODER&=~((1U<<4)|(1U<<6));
	GPIOA->AFR[0] |= (7<<12)|(7<<8);

	/*	UART Configuration */
	RCC->APB1ENR |= (1U<<17);
	USART2->BRR=833; //8000000/9600
	USART2->CR1=(1U<<0)|(1U<<2)|(1U<<3);

	while(1)
	{
		int c= uart_rx();
		uart_tx(c);
	}
}

void uart_tx(char c)
{
	while(!(USART2->ISR& (1U<<7)));
	USART2->TDR=c;
}

uint8_t uart_rx(void)
{
	uint8_t val;
	while(!(USART2->ISR& (1U<<5)));
	val=USART2->RDR;
	return val;
}

void uart_str(unsigned char *ptr)
{
	while(*ptr)
	{
		while(!(USART2->ISR&(1U<<7)));
		USART2->TDR=(*ptr);
		ptr++;
	}
}


void delay(unsigned int a)
{
	unsigned int i,j;
	for(i=0;i<a;i++)
		for(j=0;j<6000;j++);
}

