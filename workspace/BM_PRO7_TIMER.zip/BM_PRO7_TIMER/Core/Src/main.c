#include "stm32f3xx.h"

int main()
{
	RCC->AHBENR |= (1U<<17);
	GPIOA->MODER |= (1U<<10);
	GPIOA->MODER &=~(1U<<11);


	RCC->APB1ENR = (1U<<0);
	TIM2->PSC = 7999; //PRESCALE
	TIM2->ARR = 100; //Ox1F4; //500
	TIM2->CNT = 0; //init COUNTER
	TIM2->CR1 = (1U<<0);


	while(1)
	{
		while(!(TIM2->SR&(1<<0)));
		TIM2->SR&=~(1U<<0);
		GPIOA->ODR^=(1U<<5);

	}
}


//void delay(int a)
//{
//	int i,j;
//	for(j=0;j<a;j++)
//		for(i=0;i<6000;i++);
//}


