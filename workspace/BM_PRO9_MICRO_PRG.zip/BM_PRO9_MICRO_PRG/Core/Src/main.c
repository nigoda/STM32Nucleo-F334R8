#define PERIPH_BASE (0x40000000UL)
#define AHB2PERIPH_OFFSET (0x8000000UL)
#define AHB2PERIPH_BASE (PERIPH_BASE + AHB2PERIPH_OFFSET)

#define GPIOA_OFFSET (0x0000UL)
#define GPIOA_BASE (AHB2PERIPH_BASE + GPIOA_OFFSET)

#define RCC_OFFSET (0x21000UL)
#define RCC_BASE (PERIPH_BASE + RCC_OFFSET)

#define AHBENR_OFFSET (0x14UL)
#define RCC_AHBENR (*(volatile unsigned int*)(RCC_BASE + AHBENR_OFFSET))

#define MODER_OFFSET (0x00UL)
#define GPIOA_MODER (*(volatile unsigned int*)(GPIOA_BASE + MODER_OFFSET))

#define ODR_OFFSET (0x14UL)
#define GPIOA_ODR (*(volatile unsigned int*)(GPIOA_BASE + ODR_OFFSET))

#define GPIOAEN (1U<<17)
#define PIN5 (1U<<5)
#define LED_PIN PIN5

int main(void)
{
	RCC_AHBENR |= GPIOAEN;
	GPIOA_MODER |= (1U<<10);
	GPIOA_MODER &=~(1U<<11);

	while(1)
	{
		GPIOA_ODR ^= LED_PIN;
		for(int i=0;i<1000;i++)
		for(int j=0;j<1000;j++){}
	}
}
