#include "stm32f3xx.h"
void delay(unsigned int a)
{
	int i,j;
	for(j=0;j<a;j++)
		for(i=0;i<6000;i++);
}

int main()
{
	RCC->AHBENR |= (1U<<18);
	GPIOB->MODER |= (1U<<20);
	GPIOB->MODER &=~(1U<<21);

	GPIOB->MODER &=~(1U<<10) | (1U<<11);
	while(1)
	{
		if(GPIOB->IDR & (1<<5))
		{
			GPIOB->ODR |= (1U<<10);
//			delay(1000);
		}

		else
		{
			GPIOB->ODR &=~(1U<<10);
//			delay(1000);

		}

	}
}
