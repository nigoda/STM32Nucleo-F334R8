#include "stm32f3xx.h"

int main()
{
	RCC->AHBENR |= (1U<<17);
	GPIOA->MODER |= (1U<<13);
	GPIOA->MODER &=~(1U<<12);
	GPIOA->AFR[0] = 0;
	GPIOA->AFR[0] |= (1<<25);

   //TIMER
	RCC->APB1ENR = (1U<<1);
	TIM3->PSC = 0; //PRESCALE
	TIM3->ARR = 10000; //Ox1F4; //500
	TIM3->CNT = 0; //init COUNTER
	TIM3->CCMR1 |= (1<<5)|(1<<6);
	TIM3->CCER=1;
	TIM3->CR1 = 1;


	while(1)
	{
		TIM3->CCR1 = 1000;
		delay(200);
		TIM3->CCR1 = 2500;
		delay(200);
		TIM3->CCR1 = 5500;
		delay(200);
		TIM3->CCR1 = 7500;
		delay(200);
		TIM3->CCR1 = 9900;
		delay(200);


	}
}


void delay(unsigned int a)
{
	unsigned int i,j;
	for(j=0;j<a;j++)
		for(i=0;i<600;i++);
}


